var GDTinGlory = {};
(function(){
UltimateLib.Research.addEngineResearch({
	id: "83afa1ed-d66d-49ed-850b-4b683cc1c9b7",
	name: "8 - Bit Graphics",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, '2D Graphics V2') >= 2;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 2
	});
UltimateLib.Research.addEngineResearch({
	id: "8e10d482-9512-4b65-aa50-dfc9237a6f5b",
	name: "16 - Bit Graphics",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, '3D Graphics V2') >= 2;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 6
	});
UltimateLib.Research.addEngineResearch({
	id: "3dab501d-f76a-43c3-9082-d9e3cfef2295",
	name: "32 - Bit Graphics",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, '3D Graphics V3') >= 2;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 6
	});
UltimateLib.Research.addEngineResearch({
	id: "e1929142-eb2c-4739-8769-4fd15c43340c",
	name: "64 - Bit Graphics",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, '3D Graphics V4') >= 3;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 8
	});
UltimateLib.Research.addEngineResearch({
	id: "eb2f175a-8230-4b90-bebc-c5566c87ad28",
	name: "References And Quotes",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Easter eggs') >= 2;

						return res;
				},
	category: "Dialogs",
	categoryDisplayName: "Dialogs",
	v: 4
	});
UltimateLib.Research.addEngineResearch({
	id: "229ee7b5-e709-412e-b7b8-e476a0482266",
	name: "Pixel Upscaler",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, '3D Graphics V2') >= 4;

						return res;
				},
	category: "Graphic",
	categoryDisplayName: "Graphic",
	v: 8
	});
UltimateLib.Research.addEngineResearch({
	id: "4a0b2590-5764-4320-a8d1-8a60a9759eb3",
	name: "Ambient Sounds",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Mono sound') >= 2;

						return res;
				},
	category: "Sound",
	categoryDisplayName: "Sound",
	v: 4
	});
UltimateLib.Research.addEngineResearch({
	id: "7401a9ef-20d9-4f61-b0ab-4694f739ded1",
	name: "More Depth Of View",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Open world') >= 3;

						return res;
				},
	category: "World Design",
	categoryDisplayName: "World Design",
	v: 8
	});
UltimateLib.Research.addEngineResearch({
	id: "cd2eddf8-8003-434a-9f76-c7a83541df96",
	name: "Props With Physics",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Dynamic Environment') >= 2;

						return res;
				},
	category: "Graphic",
	categoryDisplayName: "Graphic",
	v: 8
	});
UltimateLib.Research.addEngineResearch({
	id: "bc80bd46-bdcd-4de6-83ce-cb18928b9abb",
	name: "Path Finding A.I.",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Self-learning A.I.') >= 2;

						return res;
				},
	category: "A.I.",
	categoryDisplayName: "AI",
	v: 10
	});
UltimateLib.Research.addEngineResearch({
	id: "34fde4b6-6526-4514-9ae0-bac47ada5982",
	name: "Beautiful Skybox",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Day & night cycle') >= 3;

						return res;
				},
	category: "World Design",
	categoryDisplayName: "World Design",
	v: 6
	});
UltimateLib.Research.addEngineResearch({
	id: "03cad66d-b6d2-4d41-9d69-e0cad22a05fb",
	name: "Splitscreen",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Stereo sound') >= 2;

						return res;
				},
	category: "Gameplay",
	categoryDisplayName: "Gameplay",
	v: 4
	});
UltimateLib.Research.addEngineResearch({
	id: "60c66cde-dbc2-41c3-83e6-e5346459c4ca",
	name: "World Generation",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Open world') >= 5;

						return res;
				},
	category: "World Design",
	categoryDisplayName: "World Design",
	v: 1
	});
UltimateLib.Research.addEngineResearch({
	id: "9875e393-1af5-4eb3-9f2e-2a3e9bbb1859",
	name: "Online Cheat Detecter",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Online play') >= 4;

						return res;
				},
	category: "Story/Quests",
	categoryDisplayName: "Story/Quests",
	v: 1
	});
UltimateLib.Research.addEngineResearch({
	id: "fd07829a-123a-4572-a3b4-38e124b330c7",
	name: "Server Hosting",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Online play') >= 2;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 6
	});
UltimateLib.Research.addEngineResearch({
	id: "83043240-1913-4c5a-b4ad-f20804547028",
	name: "4K Resolution",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, '3D Graphics V5') >= 3;

						return res;
				},
	category: "Graphic",
	categoryDisplayName: "Graphic",
	v: 12
	});
UltimateLib.Research.addEngineResearch({
	id: "69d332d3-80b6-4e45-bd37-052a73e338b6",
	name: "Improved Menus",
	canResearch: function () {
							var res = true;

						return res;
				},
	category: "Gameplay",
	categoryDisplayName: "Gameplay",
	v: 1
	});
UltimateLib.Research.addEngineResearch({
	id: "87884fb0-33ec-48fe-83ff-42021e43db7d",
	name: "Increased RAM Capacity",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Save game') >= 3;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 4
	});
UltimateLib.Research.addEngineResearch({
	id: "0ab3e32a-85c4-4d94-aeb8-643ef76067ec",
	name: "Beautiful Sights",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Game tutorials') >= 4;

						return res;
				},
	category: "World Design",
	categoryDisplayName: "World Design",
	v: 2
	});
UltimateLib.Research.addEngineResearch({
	id: "459b853a-857e-4011-ba6a-02817bad7896",
	name: "Bonus Missions",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Linear story') >= 2;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 1
	});
UltimateLib.Research.addEngineResearch({
	id: "05795f7a-8c26-4534-90e8-2ae3053bb76a",
	name: "Plot Twists",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Branching story') >= 3;

						return res;
				},
	category: "Story/Quests",
	categoryDisplayName: "Story/Quests",
	v: 4
	});
UltimateLib.Research.addEngineResearch({
	id: "66a7b7b9-4678-43e1-b3f1-ca31efb4e939",
	name: "Optimized RAM Capacity",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, 'Day & night cycle') >= 3;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 6
	});
UltimateLib.Research.addEngineResearch({
	id: "cdce5744-6c77-4d3c-80b1-75ebb6c746f1",
	name: "Higher Frame Rate",
	canResearch: function () {
							var res = true;
							res =   LevelCalculator.getFeatureLevel(GameManager.company, '3D Graphics V2') >= 2;

						return res;
				},
	category: "Engine",
	categoryDisplayName: "Engine",
	v: 4
	});

GDT.addPlatform({
	id:"8e4d7214-3d7c-4765-a707-72c38e9f8a4d",
	name:"Lagintosh",
	company:"Gravel",
	startAmount:0.275,
	unitsSold:0.49,
	licencePrize:3E4,
	published:"1/11/1",
	platformRetireDate:"6/2/4",
	developmentCosts:1E4,
	genreWeightings:[  0.9, 0.8, 0.6, 0.9, 1, 1 ],
	audienceWeightings:[  0.7, 1, 0.9 ],
	techLevel:2,
	iconUri:"./mods/GDTinGlory/images/platforms/McLagintosh.png",
	events:[{
	id: "0f40548d-4303-415e-981d-6c3b9b90cd14",
	date: "15/8/4",
	isRandom: false,
	ignoreGameLengthModifier: false,
	maxTriggers: 1,
	getNotification: function(company){ return new Notification({
	header: "Ninvento Tries Again",
	text: "Once again Ninvento gives themselves another life, but is it enough to convince us all that they deserve our attention? Coming up is their next portable: Ninvento 2Screen, it is what the name says. Can they really redo the succes of the Gameling?",
	image: "",
	buttonText: "OK",
	weeksUntilFired: 0
	});} 
	}
]
	});
GDT.addPlatform({
	id:"3e8eb9d2-ce35-47d1-8d6e-8b8faab6acf2",
	name:"Ninvento 2Screen",
	company:"Ninvento",
	startAmount:6E4,
	unitsSold:2E4,
	licencePrize:5E5,
	published:"16/1/1",
	platformRetireDate:"20/3/2",
	developmentCosts:1E5,
	genreWeightings:[  1, 0.9, 1, 0.7, 1, 0.9 ],
	audienceWeightings:[  1, 0.9, 0.7 ],
	techLevel:4,
	iconUri:"",
	events:[{
	id: "0f40548d-4303-415e-981d-6c3b9b90cd14",
	date: "15/8/4",
	isRandom: false,
	ignoreGameLengthModifier: false,
	maxTriggers: 1,
	getNotification: function(company){ return new Notification({
	header: "Ninvento Tries Again",
	text: "Once again Ninvento gives themselves another life, but is it enough to convince us all that they deserve our attention? Coming up is their next portable: Ninvento 2Screen, it is what the name says. Can they really redo the succes of the Gameling?",
	image: "",
	buttonText: "OK",
	weeksUntilFired: 0
	});} 
	}
]
	});
GDT.addPlatform({
	id:"578d0718-835c-4e14-9bdb-c366d533cd26",
	name:"Ninvento NonReal Kid",
	company:"Ninvento",
	startAmount:0.6,
	unitsSold:0.1,
	licencePrize:1E5,
	published:"6/5/4",
	platformRetireDate:"7/1/1",
	developmentCosts:1E5,
	genreWeightings:[  0.9, 1, 0.8, 1, 0.6, 0.7 ],
	audienceWeightings:[  0.7, 1, 0.9 ],
	techLevel:3,
	iconUri:"./mods/GDTinGlory/images/platforms/NonReal Kid.png",
	events:[{
	id: "8c2fa05c-4f8d-489c-83f0-5b6e65e18d0e",
	date: "6/10/2",
	isRandom: false,
	ignoreGameLengthModifier: false,
	maxTriggers: 1,
	getNotification: function(company){ return new Notification({
	header: "Breaking News!",
	text: "The NonReal Kid from Ninvento has failed to introduce virtual reality, \\\"The world is just not ready yet.\\\" says the leading manager of the company, who must now face his great mistake and the huge losses. Many believe this is the end to Ninvento.",
	image: "",
	buttonText: "OK",
	weeksUntilFired: 0
	});} 
	}
,{
	id: "87ef23e8-69d8-48a9-90ab-8660805c7566",
	date: "6/5/1",
	isRandom: false,
	ignoreGameLengthModifier: false,
	maxTriggers: 1,
	getNotification: function(company){ return new Notification({
	header: "Gaming News",
	text: "Ninvento has in a recently interview told the public abot how Virtual Reality, soon will become the next revolution for gaming industry around the world. To interact with objects like they were in front of you sound promising, but experts are skeptical.",
	image: "",
	buttonText: "OK",
	weeksUntilFired: 0
	});} 
	}
]
	});
GDT.addPlatform({
	id:"13271aa2-4887-4378-8bde-d288679fae4c",
	name:"Safari 6200",
	company:"Safari",
	startAmount:0.45,
	unitsSold:0.55,
	licencePrize:7E4,
	published:"3/4/2",
	platformRetireDate:"7/1/1",
	developmentCosts:4E4,
	genreWeightings:[  0.9, 1, 0.6, 0.7, 0.7, 1 ],
	audienceWeightings:[  0.8, 1, 0.9 ],
	techLevel:3,
	iconUri:"./mods/GDTinGlory/images/platforms/Atari Platform 1.1.png",
	events:[{
	id: "d92a0439-ae77-4d02-af1b-c86369a20993",
	date: "2/8/4",
	isRandom: false,
	ignoreGameLengthModifier: false,
	maxTriggers: 1,
	getNotification: function(company){ return new Notification({
	header: "Gaming Notification",
	text: "The creators of popular games like PitRunner has now revealed that they are launching a platform supporting all their games! Yes, the fans have been heard, the Safari 6200 is coming next year!",
	image: "",
	buttonText: "OK",
	weeksUntilFired: 0
	});} 
	}
]
	});
GDT.addPlatform({
	id:"89100deb-9014-4631-9e35-a3ce3661d2a5",
	name:"NES NitroGrafX - 16",
	company:"NES",
	startAmount:0.8,
	unitsSold:1,
	licencePrize:9E4,
	published:"6/7/1",
	platformRetireDate:"10/1/1",
	developmentCosts:8E4,
	genreWeightings:[  0.7, 1, 1, 0.6, 0.9, 0.8 ],
	audienceWeightings:[  1, 1, 0.8 ],
	techLevel:3,
	iconUri:"./mods/GDTinGlory/images/platforms/NES NitroGrafX 16.png",
	events:[{
	id: "c5a081f8-f255-4799-9a9c-c987fdfa2b98",
	date: "6/4/1",
	isRandom: false,
	ignoreGameLengthModifier: false,
	maxTriggers: 1,
	getNotification: function(company){ return new Notification({
	header: "NES in spotlight",
	text: "NES has once again shared information about their newest platform. This time, they have promised us the following - \\nHigh-end 16 bit Graphics, 500 mb of RAM and 1 ghz fast processor. If you want beautiful games, this is the platform to invest in.\\nComing later this year.",
	image: "",
	buttonText: "OK",
	weeksUntilFired: 0
	});} 
	}
]
	});

GDT.addTopics([
{ 
	id: "bda0d615-5fdf-4e21-8ac5-452dca58492a",
	name: "Human Body",
	genreWeightings: [  0.8, 1, 0.7, 1, 0.8, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "f276afe7-53ec-4f9f-8ea0-760d7e2cbf13",
	name: "Dreaming",
	genreWeightings: [  1, 1, 0.9, 0.9, 0.7, 0.6 ],
	audienceWeightings: [  1, 1, 1 ]
	 }
,{ 
	id: "feea6748-d635-41f8-b52e-52c38e5ee280",
	name: "Ocean",
	genreWeightings: [  1, 1, 0.7, 1, 0.8, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "0a0df1b2-cf3f-4ba3-87e4-323173981ffc",
	name: "Playground",
	genreWeightings: [  0.7, 0.9, 1, 1, 0.6, 1 ],
	audienceWeightings: [  1, 0.9, 0.6 ]
	 }
,{ 
	id: "710f0af1-4791-47c7-bb86-517d0f569604",
	name: "Future",
	genreWeightings: [  1, 1, 0.9, 1, 1, 0.6 ],
	audienceWeightings: [  0.9, 1, 1 ]
	 }
,{ 
	id: "f756fe50-5a06-4dd1-8abf-43ecf195936e",
	name: "Hack n\u00B4 Slash",
	genreWeightings: [  1, 1, 1, 0.6, 0.9, 0.6 ],
	audienceWeightings: [  0.8, 0.9, 1 ]
	 }
,{ 
	id: "45c2049b-02b5-43ce-b984-2bc4ad6e9653",
	name: "Beat em\u00B4 Up",
	genreWeightings: [  1, 0.7, 0.6, 1, 0.9, 0.9 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "dc747f92-8dab-40f7-b85a-70f4ff8d75ea",
	name: "Words",
	genreWeightings: [  0.6, 0.7, 0.6, 0.9, 1, 1 ],
	audienceWeightings: [  1, 1, 0.6 ]
	 }
,{ 
	id: "300f7956-5af5-48a2-94a0-fa417959262c",
	name: "Puzzle",
	genreWeightings: [  0.7, 0.9, 0.9, 0.7, 1, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "e86c3871-eca3-4f0b-ac49-5e398f9d2d70",
	name: "Traffic",
	genreWeightings: [  0.9, 0.7, 0.6, 1, 0.9, 1 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "d8b2062e-3c4c-459f-b700-c3ea6f0c1698",
	name: "Mall",
	genreWeightings: [  0.7, 0.8, 0.9, 1, 0.7, 1 ],
	audienceWeightings: [  1, 1, 0.6 ]
	 }
,{ 
	id: "256354fc-a3a8-4122-8420-ecad1bcd4201",
	name: "To The Moon",
	genreWeightings: [  1, 1, 0.7, 1, 1, 0.8 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "428da4ce-5c9e-4e82-92f4-81fa3ca4de18",
	name: "Planets",
	genreWeightings: [  1, 1, 0.9, 0.9, 0.9, 0.6 ],
	audienceWeightings: [  0.7, 1, 1 ]
	 }
,{ 
	id: "8f28c865-5d34-4ae9-962b-180058e91b61",
	name: "Endless Runner",
	genreWeightings: [  1, 1, 0.6, 0.6, 0.7, 1 ],
	audienceWeightings: [  1, 1, 0.8 ]
	 }
,{ 
	id: "95633529-ddfb-4620-bde8-8e290ab9e97e",
	name: "Trains",
	genreWeightings: [  0.7, 0.9, 0.7, 1, 0.9, 1 ],
	audienceWeightings: [  0.9, 1, 0.7 ]
	 }
,{ 
	id: "960de7e1-00fa-477c-8da6-76685d35cd50",
	name: "Ships",
	genreWeightings: [  0.9, 1, 0.6, 1, 0.8, 1 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "9a516e9c-0a77-41b8-8967-22ad985c7a66",
	name: "Cooking",
	genreWeightings: [  0.7, 0.8, 0.9, 1, 0.7, 1 ],
	audienceWeightings: [  1, 1, 0.6 ]
	 }
,{ 
	id: "bae20ffc-aea8-423d-9aaf-9a284628724d",
	name: "World War II",
	genreWeightings: [  1, 0.9, 0.8, 0.8, 1, 0.6 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "915b63e9-b5d3-47ec-aced-1c7a909adea9",
	name: "Casino",
	genreWeightings: [  0.8, 0.9, 1, 1, 0.9, 1 ],
	audienceWeightings: [  0.9, 1, 0.7 ]
	 }
,{ 
	id: "1c73c2ec-4cab-4b5b-a7a7-84558a14af9b",
	name: "FPS",
	genreWeightings: [  1, 0.9, 0.7, 0.8, 0.8, 0.6 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "1eb4f4e7-c9f9-4fa5-97ab-9279ba5fe6ea",
	name: "Tower Defense",
	genreWeightings: [  1, 0.8, 0.6, 0.7, 1, 1 ],
	audienceWeightings: [  1, 1, 0.9 ]
	 }
,{ 
	id: "c1688864-9470-48ba-b0c3-0043f3732536",
	name: "Platformer",
	genreWeightings: [  0.8, 1, 0.7, 0.7, 0.6, 1 ],
	audienceWeightings: [  1, 0.9, 0.6 ]
	 }
,{ 
	id: "4a89496f-3796-4fd6-9f16-185f11f2c7a8",
	name: "Imagination",
	genreWeightings: [  0.9, 1, 0.7, 0.9, 0.7, 1 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "c54c672e-0cf9-4914-b288-a52fc6ea7cfa",
	name: "Sandbox",
	genreWeightings: [  1, 1, 0.9, 0.7, 0.7, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "4ebe18e8-3218-429a-8631-b86553eb4f7b",
	name: "Books",
	genreWeightings: [  0.8, 1, 0.7, 0.9, 0.6, 0.9 ],
	audienceWeightings: [  0.9, 1, 0.7 ]
	 }
,{ 
	id: "fa7254f0-c6bf-4033-bf8f-4660bc44d3aa",
	name: "Parachuting",
	genreWeightings: [  1, 1, 0.7, 1, 0.6, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "018e9aa4-0694-475b-85f3-96c7757dc776",
	name: "Card Game",
	genreWeightings: [  0.9, 0.7, 0.6, 0.7, 1, 1 ],
	audienceWeightings: [  1, 1, 0.6 ]
	 }
,{ 
	id: "edac401c-da30-429e-bed1-cb40893a66e3",
	name: "Afterlife",
	genreWeightings: [  0.9, 1, 1, 0.6, 0.7, 0.6 ],
	audienceWeightings: [  0.7, 1, 0.9 ]
	 }
,{ 
	id: "feb78154-e1fc-4b78-b0bc-39c6e92e7ce3",
	name: "Underground",
	genreWeightings: [  0.9, 1, 0.7, 1, 0.8, 0.9 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "47359256-7feb-46e5-92a5-e887af6b1f34",
	name: "Farm",
	genreWeightings: [  0.7, 0.9, 0.8, 1, 0.9, 1 ],
	audienceWeightings: [  1, 0.9, 0.7 ]
	 }
,{ 
	id: "bcbe2838-6cac-4f72-96ae-7b03c2206756",
	name: "Neverland",
	genreWeightings: [  0.7, 1, 1, 0.8, 0.6, 0.9 ],
	audienceWeightings: [  1, 0.9, 0.6 ]
	 }
,{ 
	id: "2f83dfd6-77de-41e4-8d82-56cc3fff3daa",
	name: "Fiction",
	genreWeightings: [  1, 1, 1, 0.6, 0.7, 0.8 ],
	audienceWeightings: [  1, 1, 1 ]
	 }
,{ 
	id: "0e3ccd8a-f7b0-418b-abfa-14a1b1ed7085",
	name: "Underwater",
	genreWeightings: [  0.8, 1, 0.8, 1, 0.7, 0.9 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "43fc0a61-c30d-47a4-9b0f-f413c4921efb",
	name: "Time",
	genreWeightings: [  0.7, 1, 0.8, 0.9, 1, 0.9 ],
	audienceWeightings: [  0.7, 1, 0.9 ]
	 }
,{ 
	id: "4f30047f-5d53-4a02-a6cc-cd29efc96808",
	name: "Arcade",
	genreWeightings: [  1, 1, 0.7, 0.6, 0.6, 1 ],
	audienceWeightings: [  1, 1, 1 ]
	 }
,{ 
	id: "63c74397-ab0b-493e-91b5-bddbd4369168",
	name: "Zoo",
	genreWeightings: [  0.7, 0.8, 0.8, 1, 0.9, 1 ],
	audienceWeightings: [  1, 0.9, 0.7 ]
	 }
,{ 
	id: "a6ff8591-0d63-4308-8446-9d2fc581f946",
	name: "Travelling",
	genreWeightings: [  0.8, 1, 0.7, 1, 0.9, 0.9 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "758ff0ce-501b-484b-a476-193ef35000e1",
	name: "Beach",
	genreWeightings: [  0.7, 0.9, 0.8, 0.9, 0.7, 0.9 ],
	audienceWeightings: [  0.9, 0.9, 0.8 ]
	 }
,{ 
	id: "53746a72-76c7-4dc4-af29-a658f171f651",
	name: "Photographer",
	genreWeightings: [  0.8, 1, 0.6, 1, 0.8, 1 ],
	audienceWeightings: [  0.7, 1, 0.9 ]
	 }
,{ 
	id: "ff3ca2a0-a2aa-4a1f-acca-a5579af6b2d9",
	name: "Factory",
	genreWeightings: [  0.7, 0.8, 0.7, 1, 1, 1 ],
	audienceWeightings: [  0.6, 1, 0.9 ]
	 }
,{ 
	id: "a4a53e2a-5553-47f0-aae0-06eb57a6f606",
	name: "Past",
	genreWeightings: [  0.8, 1, 0.9, 0.7, 0.8, 0.6 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "cae046a5-3048-4409-b4f9-bccf213206c7",
	name: "Sewer",
	genreWeightings: [  1, 0.8, 0.7, 0.9, 0.7, 0.6 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "dbb37079-0c5f-49e0-828d-b5194553027c",
	name: "Nuclear War",
	genreWeightings: [  1, 0.9, 0.7, 0.9, 1, 0.6 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "9dd3dc5d-1974-4bdb-9eed-2e50fa6a8ac7",
	name: "Cars",
	genreWeightings: [  1, 0.8, 0.6, 1, 0.7, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "33f85823-9a47-4423-bbd4-d5d82bfe0162",
	name: "Destruction Derby",
	genreWeightings: [  1, 0.7, 0.6, 1, 0.9, 0.8 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "f4bb5c8d-0dc2-4ad3-a800-5a099caf9256",
	name: "Internet",
	genreWeightings: [  0.9, 1, 1, 0.8, 0.9, 0.7 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "05fe4ae7-8b59-48c9-9b24-11dd085df7a4",
	name: "Night",
	genreWeightings: [  1, 1, 0.7, 0.8, 0.8, 0.6 ],
	audienceWeightings: [  0.7, 0.8, 1 ]
	 }
,{ 
	id: "078fd97c-1789-4c5f-82da-9992b9daae59",
	name: "Jumpscares",
	genreWeightings: [  1, 1, 0.6, 0.7, 0.6, 0.6 ],
	audienceWeightings: [  0.6, 0.7, 1 ]
	 }
,{ 
	id: "c0ba732b-f83f-409a-b00d-672189ee140e",
	name: "Circus",
	genreWeightings: [  0.7, 0.8, 0.9, 0.9, 0.7, 1 ],
	audienceWeightings: [  1, 0.9, 0.6 ]
	 }
,{ 
	id: "54678d07-e914-415b-aed1-3d346d6ec43d",
	name: "Olympic Games",
	genreWeightings: [  1, 0.8, 0.7, 1, 0.9, 1 ],
	audienceWeightings: [  0.9, 1, 0.7 ]
	 }
,{ 
	id: "14dc78d6-3030-4ed3-a6e2-ad1893885bd9",
	name: "F1 Racing",
	genreWeightings: [  1, 0.7, 0.6, 1, 0.8, 1 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "17709b91-d992-4ea6-a1d6-dca8307496cc",
	name: "Virus",
	genreWeightings: [  1, 0.8, 0.6, 1, 1, 0.7 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "c39353bb-9ac6-44b4-9aeb-668bcfe8c7c1",
	name: "Border",
	genreWeightings: [  0.7, 0.7, 0.9, 1, 0.9, 1 ],
	audienceWeightings: [  0.9, 1, 0.8 ]
	 }
,{ 
	id: "23cff438-c5c1-415e-94c7-35bd2cf5e8af",
	name: "Climbing",
	genreWeightings: [  1, 1, 0.6, 1, 0.7, 0.9 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "934d0de0-f9bd-47de-988f-ed70486435f0",
	name: "Conquest",
	genreWeightings: [  1, 0.8, 0.7, 0.8, 1, 0.6 ],
	audienceWeightings: [  0.6, 1, 1 ]
	 }
,{ 
	id: "bae8b107-85b0-47db-9983-c68acd493676",
	name: "Survival",
	genreWeightings: [  1, 1, 0.7, 1, 0.9, 0.6 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "41231403-252b-41e1-94b6-62a8aaf0d760",
	name: "Adrenalin",
	genreWeightings: [  1, 0.9, 0.6, 1, 0.7, 0.7 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "3aaeca1a-45ec-448b-a9c3-a88821c11d32",
	name: "Empire",
	genreWeightings: [  1, 0.8, 0.9, 0.8, 1, 0.6 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "df118a3c-1149-4540-9fbf-cf3b55b45c25",
	name: "Sumo",
	genreWeightings: [  1, 0.7, 0.6, 1, 0.9, 0.9 ],
	audienceWeightings: [  0.9, 0.9, 1 ]
	 }
,{ 
	id: "119cecf4-add9-41b5-9376-c4a472af0043",
	name: "Boxing",
	genreWeightings: [  1, 0.7, 0.6, 0.9, 0.8, 1 ],
	audienceWeightings: [  0.8, 0.9, 1 ]
	 }
,{ 
	id: "de3614be-1e61-4bb8-9fd0-ad6ad4defdaf",
	name: "Middle Earth",
	genreWeightings: [  1, 1, 1, 0.6, 1, 0.8 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "5bbd8525-da8c-40ba-a753-8d9cb9828973",
	name: "Gangster",
	genreWeightings: [  1, 0.8, 0.9, 0.8, 0.9, 0.7 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "78e2badb-9d8a-4931-9942-cdb7eec74b4c",
	name: "Mafia",
	genreWeightings: [  1, 0.7, 1, 0.7, 0.8, 0.6 ],
	audienceWeightings: [  0.6, 0.8, 1 ]
	 }
,{ 
	id: "440b098b-794f-44ea-a9ce-11db46024fa0",
	name: "Kung Fu",
	genreWeightings: [  1, 0.9, 0.9, 0.6, 0.7, 1 ],
	audienceWeightings: [  0.9, 1, 0.9 ]
	 }
,{ 
	id: "2ae3e972-c653-4919-92d5-887a76c5faf7",
	name: "Comics",
	genreWeightings: [  0.8, 1, 0.7, 0.6, 0.7, 0.9 ],
	audienceWeightings: [  1, 0.9, 0.7 ]
	 }
,{ 
	id: "8d4a9753-df6e-44e2-88d0-c87146305505",
	name: "Fitness",
	genreWeightings: [  0.8, 0.8, 0.6, 1, 0.9, 1 ],
	audienceWeightings: [  0.7, 1, 0.8 ]
	 }
,{ 
	id: "a66f7252-b434-4695-8f91-5e984f196498",
	name: "Pinball",
	genreWeightings: [  1, 0.7, 0.6, 0.7, 0.6, 1 ],
	audienceWeightings: [  1, 1, 0.7 ]
	 }
,{ 
	id: "eed31238-a962-4ac4-9e58-9aacc2d7a4a9",
	name: "World War I",
	genreWeightings: [  1, 0.7, 0.9, 0.9, 1, 0.6 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "01d72a12-b364-436a-8ee2-78401eabb204",
	name: "Infiltration",
	genreWeightings: [  1, 0.9, 0.7, 0.8, 1, 0.6 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "1b37ae85-3f87-4e23-90c2-61b2f4d3762f",
	name: "Laser Tag",
	genreWeightings: [  1, 0.7, 0.6, 1, 0.9, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.8 ]
	 }
,{ 
	id: "dc7c6ef8-3a6c-4e9f-a08c-c0235da1dbca",
	name: "Street Racing",
	genreWeightings: [  1, 0.8, 0.7, 0.7, 0.6, 1 ],
	audienceWeightings: [  0.9, 1, 1 ]
	 }
,{ 
	id: "f690bd61-ca37-410e-9b47-39d9bc969cf2",
	name: "Snow Sports",
	genreWeightings: [  1, 1, 0.6, 1, 0.7, 0.9 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }
,{ 
	id: "b6910b63-823a-40ad-86a1-b73663499e76",
	name: "Plot Twist",
	genreWeightings: [  1, 0.7, 1, 0.6, 0.8, 0.6 ],
	audienceWeightings: [  0.7, 0.9, 1 ]
	 }
,{ 
	id: "29fe2648-ab46-4d4e-b6c9-6566324ff63d",
	name: "Robbery",
	genreWeightings: [  1, 0.7, 0.9, 0.9, 1, 0.8 ],
	audienceWeightings: [  0.6, 0.9, 1 ]
	 }
,{ 
	id: "adec6210-b35a-4a94-8b28-97e340b220e2",
	name: "TV Show",
	genreWeightings: [  0.7, 0.8, 1, 0.9, 0.7, 0.9 ],
	audienceWeightings: [  0.9, 1, 0.6 ]
	 }
,{ 
	id: "46119698-ec89-4025-9452-2d3e097c3788",
	name: "Space Stations",
	genreWeightings: [  0.9, 1, 0.8, 1, 0.8, 0.6 ],
	audienceWeightings: [  0.8, 1, 0.9 ]
	 }

]);

GDT.addEvent({
	id: "48be10b3-610b-4449-8d6a-acd8377856b2",
	date: "10/1/1",
	isRandom: false,
	ignoreGameLengthModifier: true,
	maxTriggers: 1,
	getNotification: function(company){ return new Notification({
	header: "10 Years",
	text: "Congratulations, your company is now 10 years old! Why not make a special game for this special team?",
	image: "",
	buttonText: "OK!",
	weeksUntilFired: 0
	});} 
	});

})();
