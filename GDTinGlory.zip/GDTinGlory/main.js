(function(){
	var ready = function () {
	};

	var error = function () {
	};

GDT.loadJs(['mods/GDTinGlory/main/code.js'], ready, error);

})();
